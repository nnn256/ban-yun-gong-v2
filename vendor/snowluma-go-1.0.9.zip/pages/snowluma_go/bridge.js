﻿/* SnowLuma Go — plugin page controller (NapCat_Go console style). */
(function () {
    "use strict";

    const $ = (id) => document.getElementById(id);
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const CHANNEL = "astrbot-plugin-page";
    const ONBOARD_KEY = "snowluma_go_onboarded_v3";
    const ONBOARD_VERSION = 3;
    const LOCAL_HOSTS = ["127.0.0.1", "localhost", "0.0.0.0", "[::]", "::"];
    const LOOPBACK_BIND_HOSTS = ["127.0.0.1", "localhost", "::1", "[::1]"];
    const STATUS_INTERVAL = 3000;
    const FAST_INTERVAL = 900;
    const LOG_INTERVAL = 2500;
    const MAX_LOG_LINES = 1200;

    const S = {
        bridge: null,
        status: null,
        releases: [],
        mirrors: [],
        logs: [],
        logOffset: 0,
        logSource: "process",
        paused: false,
        busy: new Set(),
        statusTimer: null,
        offlineWarned: false,
        revealedPassword: "",
        onboarding: { steps: [], idx: 0 },
        context: {},
        qqVncAddress: "",
        qqLiveAvailable: false,
        theme: "dark",
        themeMode: "auto",
        themeTouched: false,
    };

    // ------------------------------------------------------------------
    // Theme: AstrBot injects data-theme and syncs it through the bridge.
    // Follow it by default; the config switch pins an explicit theme.
    // ------------------------------------------------------------------

    const THEME_KEY = "snowluma_go_theme_v2";
    const THEME_MODES = ["auto", "light", "dark"];

    function storedTheme() {
        try {
            const value = localStorage.getItem(THEME_KEY);
            if (THEME_MODES.includes(value)) return value;
        } catch (error) { /* sandboxed iframe */ }
        return "";
    }

    function astrbotTheme() {
        const context = (S.bridge && typeof S.bridge.getContext === "function"
            ? S.bridge.getContext()
            : null) || S.context || {};
        if (typeof context.isDark === "boolean") return context.isDark ? "dark" : "light";
        const attr = document.documentElement.getAttribute("data-theme");
        return attr === "light" ? "light" : "dark";
    }

    function applyTheme(mode, persist) {
        const wanted = THEME_MODES.includes(mode) ? mode : "auto";
        const effective = wanted === "auto" ? astrbotTheme() : wanted;
        S.themeMode = wanted;
        S.theme = effective;
        document.documentElement.setAttribute("data-theme", effective);
        const toggle = $("cfg-light-mode");
        if (toggle) toggle.checked = effective === "light";
        const follow = $("link-follow-theme");
        if (follow) follow.style.display = wanted === "auto" ? "none" : "";
        if (persist) {
            try { localStorage.setItem(THEME_KEY, wanted); } catch (error) { /* ignore */ }
        }
    }

    applyTheme(storedTheme() || "auto");

    // ------------------------------------------------------------------
    // Bridge: use AstrBot's SDK when injected, otherwise speak the same
    // postMessage protocol ourselves. AstrBot injects the SDK at the end of
    // <body>, i.e. *after* this script, and some builds fail to serve it at
    // all; depending on it alone left the page without a backend.
    // ------------------------------------------------------------------

    function createFallbackBridge() {
        const origin = window.location.origin;
        const pending = new Map();
        let seq = 0;
        let context = null;
        let resolveReady;
        const ready = new Promise((resolve) => { resolveReady = resolve; });

        window.addEventListener("message", (event) => {
            if (event.source !== window.parent) return;
            if (origin !== "null" && event.origin !== origin && event.origin !== "null") return;
            const message = event.data;
            if (!message || message.channel !== CHANNEL) return;

            if (message.kind === "context") {
                context = message.context || {};
                if (resolveReady) { resolveReady(context); resolveReady = null; }
                return;
            }
            if (message.kind === "response") {
                const waiter = pending.get(message.requestId);
                if (!waiter) return;
                pending.delete(message.requestId);
                if (message.ok) waiter.resolve(message.data);
                else waiter.reject(new Error(message.error || "插件后台请求失败"));
            }
        });

        function send(kind, payload) {
            try {
                window.parent.postMessage(
                    { channel: CHANNEL, kind, ...(payload || {}) },
                    origin === "null" ? "*" : origin
                );
            } catch (error) { /* iframe detached */ }
        }

        function request(action, payload, timeoutMs) {
            return new Promise((resolve, reject) => {
                const requestId = "slgo_" + (++seq);
                const timer = setTimeout(() => {
                    pending.delete(requestId);
                    reject(new Error("请求超时：仪表盘没有响应"));
                }, timeoutMs || 15000);
                pending.set(requestId, {
                    resolve: (value) => { clearTimeout(timer); resolve(value); },
                    reject: (error) => { clearTimeout(timer); reject(error); },
                });
                send("request", { requestId, action, ...payload });
            });
        }

        send("ready");
        // Never block the UI forever when the page is opened outside AstrBot.
        setTimeout(() => { if (resolveReady) { resolveReady(context || {}); resolveReady = null; } }, 3500);

        return {
            ready: () => ready,
            getContext: () => context,
            apiGet: (endpoint, params) => request("api:get", { endpoint, params }),
            apiPost: (endpoint, body, timeoutMs) => request("api:post", { endpoint, body }, timeoutMs),
            onContext: (handler) => { if (typeof handler === "function" && context) handler(context); },
        };
    }

    async function resolveBridge() {
        const existing = window.AstrBotPluginPage || window.AstrBotPluginView;
        if (existing) return existing;
        await sleep(400);
        const late = window.AstrBotPluginPage || window.AstrBotPluginView;
        if (late) return late;
        console.warn("[snowluma] AstrBot bridge SDK not injected; using built-in bridge");
        const fallback = createFallbackBridge();
        if (!window.AstrBotPluginPage) window.AstrBotPluginPage = fallback;
        return fallback;
    }

    const apiGet = (endpoint, params) => S.bridge.apiGet(endpoint, params);
    const apiPost = (endpoint, body, timeoutMs) => S.bridge.apiPost(endpoint, body || {}, timeoutMs);

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    function esc(value) {
        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    }

    // Remote AstrBot visitors must not be sent to their own 127.0.0.1 when
    // SnowLuma actually runs on the server. Mirror NapCat_Go's behaviour:
    // replace only loopback hosts with the hostname used to open this page.
    function rewriteUrlForCurrentHost(url) {
        if (!url) return url;
        const currentHost = window.location.hostname;
        if (!currentHost) return url;
        try {
            const parsed = new URL(url);
            if (LOCAL_HOSTS.includes(parsed.hostname)) parsed.hostname = currentHost;
            return parsed.toString();
        } catch (error) {
            return String(url).replace(/127\.0\.0\.1|localhost|0\.0\.0\.0|\[::\]/g, currentHost);
        }
    }

    function currentWebUIUrl() {
        const status = S.status || {};
        const raw = status.webui_url || "";
        if (!raw) return "";
        const bindHost = String(status.webui_bind_host || "").trim();
        // If the user explicitly keeps SnowLuma on loopback, don't advertise a
        // remote URL that cannot work. 0.0.0.0 means all interfaces, so it is
        // *not* local-only even though it appears in LOCAL_HOSTS.
        if (LOOPBACK_BIND_HOSTS.includes(bindHost)) return raw;
        return rewriteUrlForCurrentHost(raw);
    }

    function toast(message, kind, duration) {
        const node = $("toast");
        node.textContent = message;
        node.className = "toast visible" + (kind ? " " + kind : "");
        clearTimeout(toast._timer);
        toast._timer = setTimeout(() => { node.className = "toast" + (kind ? " " + kind : ""); }, duration || 3000);
    }

    function confirmDialog(message, okLabel) {
        return new Promise((resolve) => {
            $("confirm-msg").textContent = message;
            $("confirm-ok").textContent = okLabel || "确定";
            $("confirm-mask").classList.add("visible");
            const done = (value) => {
                $("confirm-mask").classList.remove("visible");
                $("confirm-ok").removeEventListener("click", onOk);
                $("confirm-cancel").removeEventListener("click", onCancel);
                resolve(value);
            };
            const onOk = () => done(true);
            const onCancel = () => done(false);
            $("confirm-ok").addEventListener("click", onOk);
            $("confirm-cancel").addEventListener("click", onCancel);
        });
    }

    // ------------------------------------------------------------------
    // One-shot sudo password: RSA-encrypted in the browser, never stored.
    // ------------------------------------------------------------------

    let sudoPubKey = null;

    async function sudoPublicKey() {
        if (sudoPubKey) return sudoPubKey;
        const data = await apiGet("sudo/key");
        if (!data || !data.n || !data.e) throw new Error("无法获取 sudo 公钥");
        sudoPubKey = {
            n: BigInt("0x" + data.n),
            e: BigInt("0x" + data.e),
            size: Number(data.size) || Math.ceil(data.n.length / 2),
        };
        return sudoPubKey;
    }

    function modPow(base, exp, mod) {
        let result = 1n;
        base %= mod;
        while (exp > 0n) {
            if (exp & 1n) result = (result * base) % mod;
            exp >>= 1n;
            base = (base * base) % mod;
        }
        return result;
    }

    async function encryptSudo(plain) {
        const key = await sudoPublicKey();
        const message = new TextEncoder().encode(plain);
        const size = key.size;
        if (message.length > size - 11) throw new Error("sudo 密码过长");
        const padLength = size - message.length - 3;
        const pad = new Uint8Array(padLength);
        crypto.getRandomValues(pad);
        for (let i = 0; i < padLength; i += 1) {
            if (pad[i] === 0) pad[i] = 1;
        }
        const block = new Uint8Array(size);
        block[0] = 0;
        block[1] = 2;
        block.set(pad, 2);
        block[2 + padLength] = 0;
        block.set(message, 3 + padLength);

        let value = 0n;
        for (let i = 0; i < block.length; i += 1) value = (value << 8n) | BigInt(block[i]);
        let cipher = modPow(value, key.e, key.n);
        const out = new Uint8Array(size);
        for (let i = size - 1; i >= 0; i -= 1) {
            out[i] = Number(cipher & 0xffn);
            cipher >>= 8n;
        }
        let binary = "";
        for (let i = 0; i < out.length; i += 1) binary += String.fromCharCode(out[i]);
        return btoa(binary);
    }

    function promptSudo(reason) {
        return new Promise((resolve) => {
            const modal = $("sudo-modal");
            if (!modal) {
                // Older cached page: still allow the operation via a native
                // prompt instead of silently doing nothing.
                const password = window.prompt(
                    (reason || "该操作需要 sudo 权限") + "\n\n请输入 sudo 密码（仅本次使用）："
                );
                if (!password) {
                    resolve(null);
                    return;
                }
                encryptSudo(password)
                    .then(resolve)
                    .catch((error) => {
                        toast("加密失败：" + (error.message || error), "err", 4000);
                        resolve(null);
                    });
                return;
            }
            const input = $("sudo-password-input");
            const okBtn = $("btn-sudo-ok");
            const cancelBtn = $("btn-sudo-cancel");
            $("sudo-reason").textContent = reason || "该操作需要 sudo 权限";
            input.value = "";
            modal.classList.add("visible");
            setTimeout(() => input.focus(), 30);

            const cleanup = () => {
                modal.classList.remove("visible");
                okBtn.removeEventListener("click", onOk);
                cancelBtn.removeEventListener("click", onCancel);
                input.removeEventListener("keydown", onKey);
                okBtn.disabled = false;
                okBtn.textContent = "确认";
            };
            const onCancel = () => { cleanup(); resolve(null); };
            const onOk = async () => {
                const password = input.value;
                if (!password) {
                    toast("请输入 sudo 密码", "warn", 2500);
                    input.focus();
                    return;
                }
                okBtn.disabled = true;
                okBtn.textContent = "加密中...";
                try {
                    const encrypted = await encryptSudo(password);
                    cleanup();
                    resolve(encrypted);
                } catch (error) {
                    okBtn.disabled = false;
                    okBtn.textContent = "确认";
                    toast("加密失败：" + (error.message || error), "err", 4000);
                }
            };
            const onKey = (event) => {
                if (event.key === "Enter") {
                    event.preventDefault();
                    onOk();
                } else if (event.key === "Escape") {
                    event.preventDefault();
                    onCancel();
                }
            };
            okBtn.addEventListener("click", onOk);
            cancelBtn.addEventListener("click", onCancel);
            input.addEventListener("keydown", onKey);
        });
    }

    function shorten(text, limit) {
        const raw = String(text == null ? "" : text);
        return raw.length > (limit || 240) ? raw.slice(0, limit || 240) + "…" : raw;
    }

    function setBusy(action, busy) {
        if (busy) S.busy.add(action); else S.busy.delete(action);
        document.querySelectorAll('[data-action="' + action + '"]').forEach((node) => {
            if (node.tagName === "BUTTON") node.disabled = !!busy;
        });
    }

    async function run(action, fn, options) {
        if (S.busy.has(action)) return null;
        setBusy(action, true);
        try {
            return await fn();
        } catch (error) {
            toast((options && options.errorPrefix ? options.errorPrefix : "") + (error.message || error), "err", 5000);
            return null;
        } finally {
            setBusy(action, false);
        }
    }

    function setValue(id, text, cls) {
        const node = $(id);
        if (!node) return;
        node.textContent = text == null ? "-" : String(text);
        node.className = "value" + (cls ? " " + cls : "");
    }

    // ------------------------------------------------------------------
    // Status rendering
    // ------------------------------------------------------------------

    function isDownloading(status) {
        const d = (status && status.download) || {};
        if (d.downloading) return true;
        return ["resolving", "downloading", "verifying", "deps", "extracting", "installing"].includes(d.phase);
    }

    function render(status) {
        maybeReloadForVersion(status);
        const configuredMode = status && status.config && status.config.ui_theme;
        if (!S.themeTouched && THEME_MODES.includes(configuredMode)) {
            applyTheme(configuredMode);
        }
        renderHeader(status);
        renderStatusGrid(status);
        renderAccounts(status);
        renderProcesses(status);
        renderGuide(status);
        renderDownload(status);
        renderAuxButtons(status);
    }

    function maybeReloadForVersion(status) {
        const version = status && status.plugin && status.plugin.code_version;
        if (!version) return;
        try {
            const key = "snowluma_go_page_version";
            const seen = localStorage.getItem(key);
            if (!seen) {
                localStorage.setItem(key, version);
                return;
            }
            if (seen !== version) {
                localStorage.setItem(key, version);
                const url = new URL(window.location.href);
                url.searchParams.set("v", version);
                window.location.replace(url.toString());
            }
        } catch (error) { /* ignore */ }
    }

    function renderHeader(status) {
        const version = status.installed_version || "";
        const flavor = status.release_flavor || "";
        const node = (status.node && status.node.version) || "";
        const mode = status.external ? "external" : status.deploy_mode || "";
        $("subtitle").textContent = status.installed
            ? ["SnowLuma " + (version || "?"), flavor ? flavor + " 包" : "", mode, node ? "Node " + node : ""]
                .filter(Boolean).join(" · ")
            : "尚未安装 SnowLuma";

        const power = $("btn-toggle-power");
        const label = $("power-label");
        power.classList.remove("power-on", "power-off", "power-downloading");
        power.disabled = false;

        if (isDownloading(status)) {
            power.classList.add("power-downloading");
            label.textContent = "安装中...";
            power.disabled = true;
        } else if (status.running) {
            power.classList.add("power-off");
            label.textContent = "停止 SnowLuma";
        } else {
            power.classList.add("power-on");
            label.textContent = status.installed ? "启动 SnowLuma" : "安装 SnowLuma";
        }
    }

    function renderStatusGrid(status) {
        const syncer = status.syncer || {};
        const accounts = status.accounts || [];
        const connections = status.connections || [];
        const qq = status.qq || {};
        const node = status.node || {};
        const first = accounts[0] || {};

        if (!status.installed) {
            setValue("s-run", "未安装", "warn");
            setValue("s-version", "未安装", "warn");
            setValue("s-webui", "未启动", "warn");
        } else if (status.running) {
            setValue("s-run", status.pid ? "运行中 · " + status.pid : "运行中", "ok");
            setValue("s-version", status.installed_version || "-", status.installed_version ? "" : "warn");
            setValue("s-webui", currentWebUIUrl() || "-", "ok");
        } else {
            setValue("s-run", "已停止", "err");
            setValue("s-version", status.installed_version || "-", status.installed_version ? "" : "warn");
            setValue("s-webui", currentWebUIUrl() || "-", "warn");
        }

        setValue("s-mode", status.deploy_mode || "-");
        setValue(
            "s-login",
            status.auth_ok
                ? "已登录" + (status.consent_required ? " · 待同意协议" : "")
                : status.running ? "未登录" : "未运行",
            status.auth_ok ? "ok" : "warn"
        );
        setValue(
            "s-uin",
            first.uin
                ? first.uin + (first.nickname ? " · " + first.nickname : "")
                : (status.consent_required ? "待同意协议" : "无在线账号"),
            first.uin ? "ok" : "warn"
        );

        const bot = syncer.astrbot_bot_found
            ? (syncer.astrbot_bot_name || syncer.astrbot_bot_id || "已找到")
            : "未找到";
        setValue("s-bot", bot, syncer.astrbot_bot_found ? "ok" : "err");
        setValue(
            "s-sync",
            syncer.last_sync_time
                ? syncer.last_sync_time.replace(/^\d{4}-/, "")
                : "尚未同步",
            syncer.last_sync_ok ? "ok" : "warn"
        );

        const runningCount = ((qq.running_pids || []).length) || 0;
        setValue(
            "s-qq",
            qq.installed
                ? (qq.version || "已安装") + (runningCount ? " · " + runningCount + " 进程" : " · 未运行")
                : "未检测到 QQ",
            qq.installed ? (runningCount ? "ok" : "warn") : "err"
        );
        setValue(
            "s-node",
            node.version ? node.version + (node.bundled ? " · 内置" : " · 系统") : "未找到",
            node.supported ? "ok" : "err"
        );
        setValue("s-conn", syncer.connection_name || "astrbot");
        setValue("s-plugin", (status.plugin && status.plugin.code_version) || "-");
        setValue("s-install-dir", status.install_dir || "-");
        setValue("s-astrbot-path", syncer.astrbot_config_path || "未找到", syncer.astrbot_config_path ? "" : "warn");

        renderPassword(status);

        // keep the sync button meaningful
        const syncBtn = $("btn-sync");
        syncBtn.disabled = !status.running || !syncer.astrbot_bot_found || S.busy.has("sync");
    }

    function renderPassword(status) {
        const node = $("s-password");
        if (!node) return;
        if (S.revealedPassword) {
            node.textContent = S.revealedPassword;
            node.classList.add("revealed");
            return;
        }
        node.classList.remove("revealed");
        node.textContent = (status && status.webui_password_masked)
            || (status && status.password_managed ? "已保存（点击显示）" : "未设置（首次启动自动生成）");
    }

    function renderAccounts(status) {
        const host = $("account-list");
        const accounts = status.accounts || [];
        const connections = status.connections || [];
        if (!accounts.length) {
            host.innerHTML = '<div class="empty-box">还没有账号上线。请启动 QQ 并完成登录' +
                (status.consent_required ? "；并先在 SnowLuma 同意用户协议。" : "。") + "</div>";
            return;
        }
        host.innerHTML = accounts.map((account) => {
            const uin = String(account.uin || "");
            const conn = connections.find((item) => String(item.uin || "") === uin) || {};
            const adapters = conn.adapters || conn.clients || conn.connections || [];
            const online = conn.online === true || conn.connected === true || (Array.isArray(adapters) && adapters.length > 0);
            const parts = [];
            if (account.nickname) parts.push(account.nickname);
            parts.push(online ? "OneBot 适配器在线" : "OneBot 适配器未连接");
            if (Array.isArray(adapters) && adapters.length) parts.push(adapters.length + " 个连接");
            return '<div class="proc-row">' +
                '<div class="who"><b>' + esc(uin) + "</b><span>" + esc(parts.join(" · ")) + "</span></div>" +
                '<div class="acts"><span class="tag ' + (online ? "ok" : "warn") + '">' +
                (online ? "在线" : "离线") + "</span>" +
                '<button class="btn btn-sm" data-action="sync">同步</button></div></div>';
        }).join("");
    }

    function statusClass(value) {
        const text = String(value || "").toLowerCase();
        if (text === "online" || text === "loaded") return "ok";
        if (text === "error" || text === "disconnected") return "err";
        if (text === "loading" || text === "connecting") return "warn";
        return "";
    }

    function renderProcesses(status) {
        const host = $("qq-process-list");
        const processes = status.qq_processes || [];
        if (!processes.length) {
            host.innerHTML = '<div class="empty-box">' + (status.qq && status.qq.installed
                ? "QQ 已安装但尚未运行，或 SnowLuma 还没有发现进程。"
                : "未检测到 QQNT，请先安装 QQ 或在配置里填写路径。") + "</div>";
            return;
        }
        host.innerHTML = processes.map((info) => {
            const pid = Number(info.pid || 0);
            const state = String(info.status || "available");
            const account = info.account && info.account.uin ? String(info.account.uin) : String(info.uin || "");
            return '<div class="proc-row">' +
                '<div class="who"><b>PID ' + pid + (account ? " · " + esc(account) : "") + "</b>" +
                "<span>" + esc(shorten(info.path || info.name || "", 90)) + "</span></div>" +
                '<div class="acts"><span class="tag ' + statusClass(state) + '">' + esc(state) + "</span>" +
                (info.injected
                    ? '<button class="btn btn-sm" data-action="hook-unload" data-pid="' + pid + '">卸载</button>'
                    : '<button class="btn btn-sm" data-action="hook-load" data-pid="' + pid + '">挂载</button>') +
                "</div></div>";
        }).join("");
    }

    function renderGuide(status) {
        const guide = $("guide");
        const parts = [];
        let kind = "";

        if ((status.qq_env || []).length) {
            kind = "warn";
            parts.push("<strong>QQ 启动环境需要修复</strong><br>" +
                esc(status.qq_env.join("、")) +
                "<br>点击「修复并启动 QQ」，在弹窗里输入 sudo 密码即可自动修复。");
            parts.push('<div class="guide-actions">' +
                '<button class="btn btn-sm btn-primary" data-action="start-qq-sudo">修复并启动 QQ</button></div>');
        } else if (status.consent_required) {
            kind = "warn";
            parts.push("<strong>需要同意 SnowLuma 协议</strong><br>SnowLuma 要求先确认用户协议与隐私政策，之后才能读写 OneBot 配置。");
            parts.push('<div class="guide-actions">' +
                '<button class="btn btn-sm" data-action="open-webui">打开 WebUI</button>' +
                '<button class="btn btn-sm btn-primary" data-action="accept-agreements">我同意</button></div>');
        } else if (!status.installed) {
            kind = "warn";
            parts.push("<strong>尚未安装 SnowLuma</strong><br>打开「配置 → 维护与帮助 → 下载与安装」，选择版本与镜像后点「安装 / 更新」即可自动下载并部署。");
        } else if (status.last_error) {
            kind = "error";
            parts.push("<strong>最近错误</strong><br>" + esc(shorten(status.last_error, 300)));
        } else if (!status.running) {
            kind = "";
            parts.push("<strong>SnowLuma 已停止</strong><br>点击左上角「启动 SnowLuma」，插件会自动登录 WebUI 并加载账号。");
        } else if (!(status.accounts || []).length) {
            kind = "";
            parts.push("<strong>等待 QQ 登录</strong><br>启动 QQ 并完成登录后，账号与 OneBot 连接会自动就绪。");
        } else if (!(status.syncer && status.syncer.last_sync_ok)) {
            kind = "warn";
            parts.push("<strong>账号已在线，等待接入</strong><br>点击「立即同步」把 AstrBot 的反向 WS 写入 SnowLuma。");
        }

        if (!parts.length) {
            guide.className = "guide";
            guide.innerHTML = "";
            return;
        }
        guide.className = "guide visible" + (kind ? " " + kind : "");
        guide.innerHTML = parts.join("");
    }

    function renderDownload(status) {
        const panel = $("download-panel");
        const data = status.download || {};
        const phase = data.phase || "idle";
        const active = isDownloading(status) || phase === "done" || phase === "failed";
        if (!active) {
            panel.className = "download-panel";
            return;
        }
        panel.className = "download-panel visible" + (phase === "done" ? " done" : phase === "failed" ? " failed" : "");
        $("dl-title-text").textContent = data.message || (phase === "done" ? "安装完成" : phase === "failed" ? "安装失败" : "正在安装 SnowLuma");
        $("dl-mirror").textContent = data.current_mirror || "";
        const percent = Math.max(0, Math.min(100, Number(data.percent) || 0));
        $("dl-progress-fill").style.width = percent + "%";
        $("dl-percent").textContent = phase === "failed" ? "失败" : percent + "%";
        $("dl-size").textContent = data.downloaded_mb
            ? data.downloaded_mb + "MB" + (data.total_mb ? " / " + data.total_mb + "MB" : "")
            : "";
        $("dl-speed").textContent = data.speed_kbps ? Math.round(data.speed_kbps) + "KB/s" : "";
    }

    function renderAuxButtons(status) {
        const installed = !!status.installed;
        const running = !!status.running;
        $("btn-qq-launch").disabled = !(status.qq && status.qq.installed) || S.busy.has("qq-launch");
        $("btn-hook-all").disabled = !running || S.busy.has("hook-all");
        $("btn-restart").disabled = !installed || S.busy.has("restart");
        $("btn-cleanup").disabled = S.busy.has("cleanup");
        $("btn-qq-cleanup").disabled = S.busy.has("qq-cleanup");
        const dlInstall = $("btn-dl-install");
        if (dlInstall) dlInstall.disabled = isDownloading(status) || S.busy.has("install");
        $("btn-open-webui").disabled = !(running && status.webui_url);
        $("btn-qq-login").disabled = !(status.qq && status.qq.installed) || S.busy.has("qq-qr");
        $("btn-fix-linux").disabled = S.busy.has("linux-fix");
        $("btn-qq-repair-ui").disabled = S.busy.has("qq-repair");
        $("btn-install-deps").disabled = S.busy.has("linux-deps");
    }

    // ------------------------------------------------------------------
    // Onboarding (first-run spotlight tour, same style as NapCat_Go)
    // ------------------------------------------------------------------

    function buildOnboardingSteps() {
        const steps = [
            {
                type: "backdrop",
                html: '<span class="ob-step-badge">WELCOME</span>' +
                    '<div class="ob-welcome-title">感谢您使用<br>SnowLuma Go</div>' +
                    '<div class="ob-welcome-sub">接下来会快速认识新界面，<br>并完成第一次 SnowLuma + QQ 接入。</div>',
            },
            {
                type: "backdrop",
                html: '<span class="ob-step-badge">1.0.2 更新</span>' +
                    "<h3>这次改了什么</h3>" +
                    "<ul>" +
                    "<li><b>下载与安装</b> 拆成独立页面：镜像、版本、发行包都在里面，选中镜像后立即生效；</li>" +
                    "<li>下载完成后自动检查 Linux 依赖；缺少时会弹窗索取 sudo 密码并自动安装（密码只用于本次操作）；</li>" +
                    "<li>虚拟屏幕改为 <code>800x600</code>，二维码截图更贴近 QQ 登录窗口；</li>" +
                    "<li>主界面重新排版：三个主按钮一行、操作提示置顶、日志区吸顶、状态卡自适应。</li>" +
                    "</ul>" +
                    '<div class="ob-hint">用过旧版也没关系，这份引导会重新出现一次，看完即可。</div>',
            },
            {
                type: "backdrop",
                html: '<span class="ob-step-badge">前置 1 / 3</span>' +
                    "<h3>在 AstrBot 中创建机器人</h3>" +
                    "<p>打开 <b>AstrBot</b> 后台 → <code>机器人</code>：</p>" +
                    "<ul>" +
                    "<li>新建机器人，平台选择 <code>OneBot v11</code> 并启用；</li>" +
                    "<li>反向 Websocket 主机填 <code>0.0.0.0</code>，端口如 <code>6199</code>；</li>" +
                    "<li>填写一个随机 Token，稍后由插件自动写入 SnowLuma。</li>" +
                    "</ul>" +
                    '<img class="ob-shot" alt="AstrBot 创建机器人" data-guide-asset="astbot-create-bot.png">' +
                    '<div class="ob-shot-cap">AstrBot 新建机器人界面（红框为关键填写项）</div>' +
                    '<div class="ob-warn-box">没有可用的 OneBot v11 机器人时，「立即同步」会保持不可用。</div>',
            },
            {
                type: "backdrop",
                html: '<span class="ob-step-badge">前置 2 / 3</span>' +
                    "<h3>下载并安装 SnowLuma</h3>" +
                    "<p>打开右上角 <b>配置</b> → <b>维护与帮助</b> → <b>下载与安装</b>：</p>" +
                    "<ul>" +
                    "<li><b>下载镜像</b>：选择后立即生效，不需要保存；下载失败仍会自动回退其他镜像；</li>" +
                    "<li><b>版本 / 发行包</b>：优先选 <code>full</code>（自带 Node）；安装会保留 <code>config/</code>、<code>data/</code> 等用户数据；</li>" +
                    "<li><b>依赖检查</b>：下载完成后自动检测 xvfb / x11vnc / fluxbox 等依赖；缺少时会弹窗索取 sudo 密码并自动安装，密码只用于本次操作。</li>" +
                    "</ul>" +
                    '<div class="ob-hint">国内网络建议保留默认镜像 <code>https://gh.zwy.one/</code>。</div>',
            },
            {
                type: "backdrop",
                html: '<span class="ob-step-badge">前置 3 / 3</span>' +
                    "<h3>首次启动还需要</h3>" +
                    "<ul>" +
                    "<li>SnowLuma 首次使用会要求同意用户协议，点页面里的 <b>我同意</b>；</li>" +
                    "<li>WebUI 密码由插件自动生成并加密保存，可在「WebUI 密码」处显示 / 复制，无需自己设置；</li>" +
                    "<li>QQ 登录必须由你在 QQ 客户端里扫码或快速登录；无桌面服务器可以直接在「QQ 登录」弹窗里扫码。</li>" +
                    "</ul>" +
                    '<div class="ob-warn-box">没有同意协议之前，同步与密码重置都会被 SnowLuma 拒绝。</div>',
            },
        ];

        const tour = [
            ["btn-toggle-power", "启动 / 停止", "一键启动或停止 SnowLuma。启动后插件会自动登录 WebUI 并加载账号。"],
            ["btn-sync", "立即同步", "把 AstrBot 的 OneBot v11 反向 WS 写入 SnowLuma。需要账号在线且已同意协议；按钮灰色表示条件未满足。"],
            ["btn-open-webui", "打开 WebUI", "弹出自定义面板，可打开 WebUI、复制自动适配后的地址与密码。"],
            ["guide", "操作提示", "这里会根据当前状态提示下一步，例如同意协议、等待 QQ 登录或同步连接。"],
            ["s-run", "运行状态", "SnowLuma 是否在运行以及进程 PID。"],
            ["s-version", "版本", "当前安装的 SnowLuma 版本号；显示「未安装」时先在「下载与安装」里安装。"],
            ["s-mode", "运行方式", "auto / native / external；external 表示接管已有 SnowLuma，不下载也不拉起进程。"],
            ["s-webui", "WebUI 地址", "当前 SnowLuma WebUI 的访问地址。"],
            ["s-login", "登录状态", "插件与 SnowLuma WebUI 的会话状态；显示「待同意协议」时先点页面里的我同意。"],
            ["s-uin", "QQ 账号", "SnowLuma 内已登录的 QQ 账号。"],
            ["s-bot", "AstrBot 机器人", "插件从 cmd_config.json 探测到的 OneBot v11 机器人。"],
            ["s-sync", "上次同步", "最近一次同步的时间与结果。"],
            ["s-qq", "QQ 客户端", "QQNT 的安装情况与运行进程数。"],
            ["s-node", "Node 运行时", "SnowLuma 使用的 Node 来源与版本；full 包自带运行时。"],
            ["s-conn", "接入连接名", "写入 SnowLuma 的 OneBot 连接名，便于在 WebUI 里辨认。"],
            ["s-plugin", "插件版本", "当前 SnowLuma Go 插件代码版本。"],
            ["s-password", "WebUI 密码", "自动生成并加密保存的密码，可以显示、复制或重置。"],
            ["s-install-dir", "安装目录", "本插件托管的 SnowLuma 程序目录；config/、data/ 等用户数据会保留。"],
            ["s-astrbot-path", "AstrBot 配置", "插件探测到的 AstrBot cmd_config.json 路径。"],
            ["btn-qq-launch", "启动 QQ", "启动 QQNT；Linux 无桌面时会在 Xvfb 虚拟显示中启动。"],
            ["btn-qq-login", "QQ 登录", "无桌面服务器可直接查看二维码；点「页面内操作」可在弹窗里实时点登录 / 切换扫码（需 xdotool）。"],
            ["btn-hook-all", "全部挂载", "让 SnowLuma 挂载所有可用的 QQ 进程。"],
            ["btn-open-config", "配置", "修改运行方式、账号、VNC、自动化等选项；安装与下载镜像在「维护与帮助 → 下载与安装」。"],
            ["log-container", "实时日志", "插件与 SnowLuma 的运行日志，出错时先看这里。"],
        ];
        tour.forEach(([target, title, desc], index) => {
            steps.push({
                type: "spotlight",
                target,
                html: '<span class="ob-step-badge">界面导览 ' + (index + 1) + " / " + tour.length + "</span>" +
                    "<h3>" + title + "</h3><p>" + desc + "</p>",
            });
        });

        steps.push({
            type: "spotlight",
            target: "btn-sync",
            urgent: true,
            html: '<span class="ob-step-badge">FINAL 重点提醒</span>' +
                '<h3 style="color:#ffd98a;">先同意协议，再同步</h3>' +
                "<ul>" +
                "<li>先去同意 SnowLuma 的用户协议 / 隐私政策；</li>" +
                "<li>确认 QQ 账号已经在线，再点「立即同步」；</li>" +
                "</ul>" +
                '<div class="ob-danger-box">同步成功后 AstrBot 的 OneBot v11 平台会显示在线；失败原因会写在日志区。</div>',
        });
        return steps;
    }

    const guideAssetCache = {};

    async function guideAssetUrl(name) {
        if (guideAssetCache[name]) return guideAssetCache[name];
        try {
            const data = await apiGet("guide/asset", { name: name });
            if (data && data.ok && data.data) {
                guideAssetCache[name] = "data:" + (data.mime || "image/png") + ";base64," + data.data;
                return guideAssetCache[name];
            }
        } catch (error) {
            /* static fallback below */
        }
        // Last resort: relative path next to the page (works on hosts that
        // serve plugin-page assets directly).
        return "./assets/" + name;
    }

    async function hydrateGuideAssets(root) {
        const images = root.querySelectorAll("img[data-guide-asset]");
        for (const img of images) {
            const name = img.dataset.guideAsset;
            if (!name || img.dataset.loaded) continue;
            const url = await guideAssetUrl(name);
            if (url) {
                img.src = url;
                img.dataset.loaded = "1";
            }
            img.addEventListener(
                "error",
                () => img.classList.add("missing"),
                { once: true }
            );
        }
    }

    function startOnboarding() {
        const ob = $("onboarding");
        if (!ob) return;
        S.onboarding.steps = buildOnboardingSteps();
        S.onboarding.idx = 0;
        ob.classList.add("visible");
        renderOnboarding();
    }

    function renderOnboarding() {
        const ob = $("onboarding");
        const card = $("ob-card");
        const steps = S.onboarding.steps;
        const index = S.onboarding.idx;
        const step = steps[index];
        if (!ob || !card || !step) return;

        const first = index === 0;
        const last = index === steps.length - 1;
        card.innerHTML = '<div class="ob-body">' +
            step.html +
            '<div class="ob-dots"><span style="font-size:11px;color:var(--text-muted);font-family:\'Consolas\',monospace;">' +
            (index + 1) + " / " + steps.length + "</span></div>" +
            '<div class="ob-actions">' +
            '<button class="ob-btn skip" data-ob="skip">' + (first ? "跳过引导" : "不再提示") + "</button>" +
            '<div class="ob-right">' +
            (!first ? '<button class="ob-btn" data-ob="prev">上一步</button>' : "") +
            '<button class="ob-btn primary" data-ob="' + (last ? "done" : "next") + '">' +
            (last ? "开始使用" : "下一步") + "</button>" +
            "</div></div>" +
            "</div>";

        hydrateGuideAssets(card);

        if (step.type === "backdrop") {
            ob.classList.remove("with-spotlight");
            ob.classList.add("with-backdrop");
            card.style.left = "50%";
            card.style.top = "50%";
            card.style.transform = "translate(-50%, -50%)";
            card.style.width = "";
        } else {
            ob.classList.remove("with-backdrop");
            // Position synchronously first: requestAnimationFrame is throttled
            // or paused in background tabs / embedded iframes, which used to
            // leave most tour steps without a spotlight. A second pass on the
            // next frame keeps the ring aligned after scrolling / layout shifts.
            positionOnboarding();
            requestAnimationFrame(positionOnboarding);
        }
    }

    function isElementVisible(el) {
        if (!el) return false;
        if (el.offsetParent === null && el.getClientRects().length === 0) return false;
        const style = window.getComputedStyle(el);
        return style.display !== "none" && style.visibility !== "hidden";
    }

    function positionOnboarding() {
        const ob = $("onboarding");
        const card = $("ob-card");
        const spot = $("ob-spotlight");
        const step = S.onboarding.steps[S.onboarding.idx];
        if (!ob || !card || !spot || !step || step.type !== "spotlight") {
            if (ob) ob.classList.remove("with-spotlight");
            return;
        }
        const target = step.target ? document.getElementById(step.target) : null;
        if (!target || !isElementVisible(target)) {
            if (S.onboarding.idx < S.onboarding.steps.length - 1) {
                S.onboarding.idx += 1;
                renderOnboarding();
            } else {
                ob.classList.remove("with-spotlight");
            }
            return;
        }

        const pad = 6;
        const margin = 16;
        target.scrollIntoView({ block: "nearest", inline: "nearest" });
        let rect = target.getBoundingClientRect();
        // `nearest` stops as soon as the element touches the viewport edge, so
        // the 6px spotlight frame could be clipped on targets at the top or
        // bottom (e.g. the header config button after scrolling). Pull them
        // fully inside with a little breathing room.
        if (rect.top - pad < margin) {
            window.scrollBy(0, rect.top - pad - margin);
            rect = target.getBoundingClientRect();
        } else if (rect.bottom + pad > window.innerHeight - margin) {
            window.scrollBy(0, rect.bottom + pad - window.innerHeight + margin);
            rect = target.getBoundingClientRect();
        }
        spot.style.left = (rect.left - pad) + "px";
        spot.style.top = (rect.top - pad) + "px";
        spot.style.width = (rect.width + pad * 2) + "px";
        spot.style.height = (rect.height + pad * 2) + "px";
        spot.classList.toggle("urgent", !!step.urgent);

        const cardWidth = Math.min(420, window.innerWidth - 32);
        const cardHeight = card.offsetHeight || 280;
        const clampLeft = (x) => Math.max(16, Math.min(window.innerWidth - cardWidth - 16, x));
        const clampTop = (y) => Math.max(16, Math.min(window.innerHeight - cardHeight - 16, y));
        let left = clampLeft(rect.left + rect.width / 2 - cardWidth / 2);
        let top;
        if (rect.bottom + 18 + cardHeight <= window.innerHeight - 8) {
            top = rect.bottom + 18;
        } else if (rect.top - 18 - cardHeight >= 8) {
            top = rect.top - cardHeight - 18;
        } else {
            // No vertical room (e.g. the tall log panel): dock the card beside
            // the target instead of covering the spotlight.
            const leftX = rect.left - cardWidth - 18;
            const rightX = rect.right + 18;
            if (leftX >= 8) {
                left = leftX;
                top = clampTop(rect.top + rect.height / 2 - cardHeight / 2);
            } else if (rightX + cardWidth <= window.innerWidth - 8) {
                left = rightX;
                top = clampTop(rect.top + rect.height / 2 - cardHeight / 2);
            } else {
                top = Math.max(16, (window.innerHeight - cardHeight) / 2);
            }
        }

        card.style.transform = "none";
        card.style.left = left + "px";
        card.style.top = top + "px";
        card.style.width = cardWidth + "px";
        ob.classList.add("with-spotlight");
    }

    function finishOnboarding() {
        const ob = $("onboarding");
        if (ob) ob.classList.remove("visible", "with-backdrop", "with-spotlight");
        try { localStorage.setItem(ONBOARD_KEY, "1"); } catch (error) { /* ignore */ }
        try { apiPost("onboarding/done").catch(() => {}); } catch (error) { /* ignore */ }
    }

    async function maybeShowOnboarding() {
        let locallyDone = false;
        try { locallyDone = localStorage.getItem(ONBOARD_KEY) === "1"; } catch (error) { /* ignore */ }
        if (locallyDone) return;

        let config = null;
        try { config = await apiGet("config"); } catch (error) { /* ignore */ }
        if (config && config.onboarding_done &&
            Number(config.onboarding_version || 0) >= ONBOARD_VERSION) {
            try { localStorage.setItem(ONBOARD_KEY, "1"); } catch (error) { /* ignore */ }
            return;
        }
        if (!S.status) return;
        startOnboarding();
    }

    // ------------------------------------------------------------------
    // Polling
    // ------------------------------------------------------------------

    async function refreshStatus() {
        let delay = STATUS_INTERVAL;
        try {
            const data = await apiGet("status");
            if (data && typeof data === "object") {
                S.status = data;
                S.offlineWarned = false;
                render(data);
                if (isDownloading(data)) delay = FAST_INTERVAL;
            }
        } catch (error) {
            if (!S.offlineWarned) {
                S.offlineWarned = true;
                $("subtitle").textContent = "无法连接插件后台";
                $("guide").className = "guide visible error";
                $("guide").innerHTML = "<strong>插件后台未响应</strong><br>" + esc(error.message || String(error)) +
                    "<br>请确认插件已在 AstrBot 中启用，并从「插件 → Snowluma Go → 打开页面」进入。";
                toast("无法连接插件后台：" + (error.message || error), "err", 5000);
            }
            delay = 5000;
        }
        clearTimeout(S.statusTimer);
        S.statusTimer = setTimeout(refreshStatus, delay);
    }

    function classifyLog(line) {
        if (/\[err\]|✘|\berror\b|失败|异常|Traceback/i.test(line)) return "log-err";
        if (/\[warn\]|⚠|warn|警告/i.test(line)) return "log-warn";
        if (/\[ok\]|✔|成功|就绪|已启动|已连接|ready/i.test(line)) return "log-ok";
        return "";
    }

    function logLine(text) {
        const raw = String(text);
        const match = raw.match(/^\[(\d{2}:\d{2}:\d{2})\]\s*/);
        const stamp = match ? '<span class="log-ts">' + esc(match[1]) + "</span> " : "";
        const body = match ? raw.slice(match[0].length) : raw;
        return '<div class="' + classifyLog(raw) + '">' + stamp + esc(body) + "</div>";
    }

    function renderLogs() {
        const view = $("log-container");
        view.innerHTML = S.logs.map(logLine).join("");
        $("log-count").textContent = S.logs.length + " 行";
        view.scrollTop = view.scrollHeight;
    }

    async function refreshLogs() {
        if (S.paused) return;
        if (S.logSource === "server") {
            try {
                const data = await apiGet("server-logs", { limit: 200 });
                const list = (data && data.list) || [];
                S.logs = list.map((entry) => {
                    const level = String(entry.level || entry.levelName || "info").toLowerCase();
                    const time = String(entry.time || entry.timestamp || "");
                    const message = entry.message || entry.msg || JSON.stringify(entry);
                    return (time ? "[" + time.slice(11, 19) + "] " : "") +
                        (level === "error" ? "[err] " : level === "warn" ? "[warn] " : "") + message;
                });
                renderLogs();
            } catch (error) { /* silent while polling */ }
            return;
        }
        try {
            const data = await apiGet("logs", { since: S.logOffset });
            const lines = (data && data.lines) || [];
            if (lines.length) {
                S.logs = S.logs.concat(lines);
                if (S.logs.length > MAX_LOG_LINES) S.logs = S.logs.slice(-MAX_LOG_LINES);
                renderLogs();
            }
            if (data && typeof data.total === "number") S.logOffset = data.total;
        } catch (error) { /* silent while polling */ }
    }

    // ------------------------------------------------------------------
    // Actions
    // ------------------------------------------------------------------

    async function actionPower() {
        if (S.busy.has("power")) return;
        S.busy.add("power");
        $("btn-toggle-power").disabled = true;
        try {
            const status = S.status || {};
            if (!status.installed) {
                openDownload();
                return;
            }
            if (status.running) {
                if (!(await confirmDialog("停止后 QQ 会断开与 AstrBot 的连接，确定停止 SnowLuma？", "停止"))) return;
                const result = await run("stop", () => apiPost("stop"));
                if (result) toast(result.message || "已停止", "ok");
            } else {
                let result = await run("start", () => apiPost("start"));
                if (result && result.need_sudo) {
                    const enc = await promptSudo(
                        "启动前需要 sudo 密码修复 NapCat 注入或设置 ptrace（仅本次使用）"
                    );
                    if (enc) result = await run("start", () => apiPost("start", { sudo_password_enc: enc }));
                }
                if (result) toast(result.message || (result.ok ? "已启动" : "启动失败"), result.ok ? "ok" : "err", 4000);
            }
            refreshStatus();
        } finally {
            S.busy.delete("power");
            if (S.status) renderHeader(S.status);
        }
    }

    async function actionSync() {
        const result = await run("sync", () => apiPost("sync"));
        if (result) toast(result.message || (result.ok ? "同步完成" : "同步失败"), result.ok ? "ok" : "err", 5000);
        refreshStatus();
    }

    async function actionStartQQ() {
        let result = await run("qq-launch", () => apiPost("qq/launch"));
        if (result && result.need_sudo) {
            const enc = await promptSudo("启动 QQ 需要 sudo 密码修复 NapCat 注入（仅本次使用）");
            if (enc) result = await run("qq-launch", () => apiPost("qq/launch", { sudo_password_enc: enc }));
        }
        if (result) toast(result.message || "已发出启动指令", result.ok ? "ok" : "err", 4000);
        refreshStatus();
    }

    async function actionHookAll() {
        const result = await run("hook-all", () => apiPost("hook/all"));
        if (result) toast(result.message || (result.ok ? "已挂载" : "挂载失败"), result.ok ? "ok" : "err", 4000);
        refreshStatus();
    }

    async function actionHook(pid, mode) {
        const action = mode === "unload" ? "hook-unload" : "hook-load";
        const result = await run(action, () => apiPost(mode === "unload" ? "hook/unload" : "hook/load", { pid: pid }));
        if (result) toast(result.message || (result.ok ? "操作完成" : "操作失败"), result.ok ? "ok" : "err");
        refreshStatus();
    }

    async function actionRestart() {
        if (!(await confirmDialog("重启会短暂中断 QQ 消息收发，继续？", "重启"))) return;
        let result = await run("restart", () => apiPost("restart"));
        if (result && result.need_sudo) {
            const enc = await promptSudo("重启前需要 sudo 密码修复 NapCat 注入（仅本次使用）");
            if (enc) result = await run("restart", () => apiPost("restart", { sudo_password_enc: enc }));
        }
        if (result) toast(result.message || (result.ok ? "已重启" : "重启失败"), result.ok ? "ok" : "err", 4000);
        refreshStatus();
    }

    async function actionCleanup() {
        if (!(await confirmDialog(
            "将停止本插件启动的 SnowLuma，并清理安装目录内的残留 node、Xvfb、x11vnc 进程。继续？",
            "清理"
        ))) return;
        const result = await run("cleanup", () => apiPost("cleanup"));
        if (result) toast(result.message || "已清理", result.ok ? "ok" : "err");
        refreshStatus();
    }

    async function actionCleanupQQ() {
        if (!(await confirmDialog(
            "将强制结束 QQ 进程（包括正在登录的 QQ）。" +
            "如果存在其他用户启动的 QQ，会再询问一次 sudo 密码。继续？",
            "清理 QQ"
        ))) return;
        let result = await run("qq-cleanup", () => apiPost("qq/cleanup"));
        if (result && Array.isArray(result.skipped) && result.skipped.length) {
            const enc = await promptSudo(
                "有属于其他系统用户的 QQ 进程，需要 sudo 密码才能结束（仅本次使用）"
            );
            if (enc) {
                result = await run("qq-cleanup", () =>
                    apiPost("qq/cleanup", { sudo_password_enc: enc })
                );
            }
        }
        if (result) {
            toast(result.message || (result.ok ? "已清理 QQ 进程" : "清理 QQ 失败"),
                result.ok ? "ok" : "err", 6000);
        }
        refreshStatus();
    }

    async function refreshQQLogin(attempt) {
        const tries = typeof attempt === "number" ? attempt : 0;
        const image = $("qq-qr-image");
        const hint = $("qq-login-hint");
        const vnc = $("qq-vnc-info");
        S.qqVncAddress = "";
        image.classList.remove("visible");
        image.removeAttribute("src");
        hint.textContent = "正在启动虚拟显示并截取 QQ 登录二维码，首次可能需要几秒；空白时请稍后点刷新。";
        vnc.textContent = "";
        let result = await run("qq-qr", () => apiPost("qq/login-qr", {}, 45000));
        if (result && result.need_sudo) {
            const enc = await promptSudo("登录 QQ 前需要 sudo 密码修复 NapCat 注入（仅本次使用）");
            if (enc) {
                result = await run("qq-qr", () =>
                    apiPost("qq/login-qr", { sudo_password_enc: enc }, 45000)
                );
            }
        }
        if (!result) return;
        if (result.ok && result.image) {
            image.src = result.image;
            image.classList.add("visible");
            hint.textContent = result.message || "扫描二维码登录 QQ";
            if (result.detail) hint.textContent += "\n\n" + result.detail;
            if (result.loading && tries < 3) {
                setTimeout(() => refreshQQLogin(tries + 1), 3000);
            }
        } else {
            hint.textContent = result.message || "未截取到二维码";
            if (result.detail) hint.textContent += "\n\n" + result.detail;
        }
        const info = result.vnc || {};
        if (info.running) {
            const host = window.location.hostname || "127.0.0.1";
            if (info.local_only) {
                S.qqVncAddress = "vnc://127.0.0.1:" + info.port;
                vnc.textContent = "VNC 仅监听本机：" + S.qqVncAddress +
                    "。远程可先建立 SSH 隧道：ssh -L " + info.port + ":127.0.0.1:" + info.port +
                    " 用户名@" + host;
            } else {
                S.qqVncAddress = "vnc://" + host + ":" + info.port;
                vnc.textContent = "VNC 地址：" + S.qqVncAddress +
                    (info.display ? "（DISPLAY=" + info.display + "）" : "");
            }
        } else {
            vnc.textContent = "VNC 未运行" + (info.display ? "（DISPLAY=" + info.display + "）" : "") +
                "；二维码截图仍可直接使用。";
        }

        // Live control inside the panel: HTTP screenshots + xdotool. This works
        // inside AstrBot's sandboxed iframe (no nested iframe / WebSocket).
        S.qqLiveAvailable = !!(info.running && info.input_available);
        const liveBtn = $("btn-qq-live");
        if (liveBtn) {
            liveBtn.disabled = !S.qqLiveAvailable;
            liveBtn.title = S.qqLiveAvailable
                ? "在弹窗内实时操作 QQ"
                : (info.running ? "未安装 xdotool，请点「安装 Linux 依赖」" : "VNC 未就绪");
        }
        if (!S.qqLiveAvailable) setQQLive(false);
        if (info.running && !info.input_available) {
            hint.textContent += "\n\n未安装 xdotool，无法在页面内点击；请到「配置 → 维护与帮助 → 安装 Linux 依赖」后再试。";
        } else if (S.qqLiveAvailable) {
            hint.textContent += "\n\n提示：点「页面内操作」后，点击画面即可操作 QQ。";
        }
    }

    let qqLiveTimer = null;
    let qqLiveBusy = false;
    let qqLiveActive = false;
    const QQ_LIVE_INTERVAL = 500;

    async function refreshQQLiveFrame() {
        if (qqLiveBusy || !S.qqLiveAvailable) return;
        qqLiveBusy = true;
        try {
            const data = await apiGet("qq/screen");
            if (data && data.ok && data.image) {
                const img = $("qq-live-image");
                if (img) {
                    img.src = data.image;
                    if (data.width) img.dataset.width = String(data.width);
                    if (data.height) img.dataset.height = String(data.height);
                }
            }
        } catch (error) { /* keep polling */ } finally {
            qqLiveBusy = false;
        }
    }

    async function qqLiveLoop() {
        if (!qqLiveActive) return;
        await refreshQQLiveFrame();
        if (!qqLiveActive) return;
        // Self-scheduling instead of setInterval: a slow capture never queues
        // overlapping requests, and the gap starts after the previous frame.
        qqLiveTimer = setTimeout(qqLiveLoop, QQ_LIVE_INTERVAL);
    }

    function startQQLivePolling() {
        if (qqLiveActive) return;
        qqLiveActive = true;
        qqLiveLoop();
    }

    function stopQQLivePolling() {
        qqLiveActive = false;
        if (qqLiveTimer) {
            clearTimeout(qqLiveTimer);
            qqLiveTimer = null;
        }
    }

    function setQQLive(on) {
        const modal = $("qq-login-modal");
        const btn = $("btn-qq-live");
        if (!modal || !btn) return;
        const enable = !!on && !!S.qqLiveAvailable;
        modal.classList.toggle("live", enable);
        btn.textContent = enable ? "切回截图" : "页面内操作";
        if (enable) {
            startQQLivePolling();
        } else {
            stopQQLivePolling();
            const img = $("qq-live-image");
            if (img) img.removeAttribute("src");
        }
    }

    function toggleQQLive() {
        const modal = $("qq-login-modal");
        if (!modal) return;
        if (!S.qqLiveAvailable) {
            toast("实时操作不可用：请先启动 QQ 并安装 xdotool（安装 Linux 依赖）", "warn", 4000);
            return;
        }
        setQQLive(!modal.classList.contains("live"));
    }

    async function sendQQInput(payload) {
        const result = await run("qq-input", () => apiPost("qq/input", payload, 15000));
        if (result && result.ok) {
            const action = payload.type === "click"
                ? "click " + payload.x + "," + payload.y
                : payload.type + " " + (payload.key || payload.text || "");
            console.debug("[snowluma] input ok:", action);
        } else if (result) {
            toast(result.message || "操作失败", "err", 4000);
        }
        return result;
    }

    function bindQQLiveEvents() {
        const still = $("qq-qr-image");
        if (still) {
            still.addEventListener("click", () => {
                if (S.qqLiveAvailable) {
                    setQQLive(true);
                } else {
                    toast("实时操作不可用：请先安装 xdotool（配置 → 维护与帮助 → 安装 Linux 依赖）", "warn", 4500);
                }
            });
        }
        const img = $("qq-live-image");
        if (img) {
            img.addEventListener("click", (event) => {
                if (!S.qqLiveAvailable) return;
                const rect = img.getBoundingClientRect();
                if (!rect.width || !rect.height) return;
                const naturalW = Number(img.dataset.width) || img.naturalWidth || rect.width;
                const naturalH = Number(img.dataset.height) || img.naturalHeight || rect.height;
                const x = Math.round((event.clientX - rect.left) * naturalW / rect.width);
                const y = Math.round((event.clientY - rect.top) * naturalH / rect.height);
                sendQQInput({ type: "click", x: x, y: y });
            });
        }
        document.querySelectorAll("[data-qqkey]").forEach((btn) => {
            btn.addEventListener("click", () =>
                sendQQInput({ type: "key", key: btn.dataset.qqkey })
            );
        });
        const text = $("qq-live-text");
        if (text) {
            text.addEventListener("keydown", (event) => {
                if (event.key !== "Enter") return;
                event.preventDefault();
                const value = text.value;
                if (!value) return;
                text.value = "";
                sendQQInput({ type: "type", text: value }).then(() => {
                    sendQQInput({ type: "key", key: "Return" });
                });
            });
        }
    }

    function openQQLoginModal() {
        setQQLive(false);
        $("qq-login-modal").classList.add("visible");
        refreshQQLogin();
    }

    function closeQQLoginModal() {
        setQQLive(false);
        $("qq-login-modal").classList.remove("visible");
    }

    async function restartQQLogin() {
        if (!(await confirmDialog(
            "将结束当前 QQ 进程，并在插件管理的虚拟显示里重新启动，继续？",
            "重启 QQ"
        ))) return;
        let result = await run("qq-restart", () => apiPost("qq/restart", {}, 45000));
        if (result && result.need_sudo) {
            const enc = await promptSudo("重启 QQ 前需要 sudo 密码修复 NapCat 注入（仅本次使用）");
            if (enc) {
                result = await run("qq-restart", () =>
                    apiPost("qq/restart", { sudo_password_enc: enc }, 45000)
                );
            }
        }
        if (result) {
            toast(result.message || (result.ok ? "QQ 已重启" : "重启 QQ 失败"),
                result.ok ? "ok" : "err", 5000);
        }
        await refreshQQLogin();
    }

    async function actionCopyQQVnc() {
        if (!S.qqVncAddress) {
            toast("当前没有可用的 VNC 地址", "warn", 3000);
            return;
        }
        await copyText(S.qqVncAddress, "VNC 地址已复制");
    }

    async function actionFixLinux() {
        if (!(await confirmDialog(
            "将使用 sudo 修正 ~/.config/QQ 的所有者与权限，并把 kernel.yama.ptrace_scope 设为 0。继续？",
            "修复权限"
        ))) return;
        const enc = await promptSudo("修复 QQ 权限需要 sudo 密码（仅本次使用）");
        if (!enc) return;
        const result = await run("linux-fix", () =>
            apiPost("linux/fix-permissions", { sudo_password_enc: enc }, 60000)
        );
        if (result) toast(result.message || (result.ok ? "修复完成" : "修复失败"),
            result.ok ? "ok" : "err", 8000);
        refreshStatus();
    }

    async function actionRepairQQ() {
        if (!(await confirmDialog(
            "会先结束 QQ 进程，再恢复被 NapCat 补丁改掉的 QQ 启动入口（package.json 的 main），" +
            "并备份 ~/.config/QQ/versions 下的热更新版本。需要 sudo 密码。继续？",
            "修复 QQ 登录界面"
        ))) return;
        const enc = await promptSudo("修复 QQ 登录界面需要 sudo 密码（仅本次使用）");
        if (!enc) return;
        const result = await run("qq-repair", () =>
            apiPost("qq/repair-ui", { sudo_password_enc: enc }, 60000)
        );
        if (result) toast(result.message || (result.ok ? "已回滚 QQ 热更新" : "修复失败"),
            result.ok ? "ok" : "err", 9000);
        refreshStatus();
    }

    async function actionInstallDeps() {
        if (!(await confirmDialog(
            "将使用 sudo apt-get 安装 xvfb、x11vnc、fluxbox、openbox、dbus-x11、" +
            "libcap2-bin、scrot、imagemagick、x11-utils、xdotool，可能需要几分钟。继续？",
            "安装依赖"
        ))) return;
        const enc = await promptSudo("安装 Linux 依赖需要 sudo 密码（仅本次使用）");
        if (!enc) return;
        const result = await run("linux-deps", () =>
            apiPost("linux/install-deps", { sudo_password_enc: enc })
        );
        if (result) toast(result.message || (result.ok ? "安装完成" : "安装失败"),
            result.ok ? "ok" : "err", 8000);
    }

    async function actionCheckUpdate() {
        const result = await run("check-update", () => apiGet("update/check"));
        if (!result) return;
        if (!result.ok) { toast(result.message || "检查更新失败", "err", 4000); return; }
        const info = result.info || {};
        const latest = info.latest || info.latestVersion || info.version || "";
        const current = result.current || (S.status && S.status.installed_version) || "";
        if (latest && current && String(latest) !== String(current)) {
            toast("SnowLuma 有新版本：" + latest + "（当前 " + current + "）", "warn", 6000);
        } else {
            toast("SnowLuma 已是最新版本" + (latest ? "（" + latest + "）" : ""), "ok", 4000);
        }
    }

    async function actionAcceptAgreements() {
        const result = await run("accept-agreements", () => apiPost("accept-agreements"));
        if (result) toast(result.message || (result.ok ? "已同意协议" : "操作失败"), result.ok ? "ok" : "err", 4000);
        refreshStatus();
    }

    function openWebUIModal() {
        const status = S.status || {};
        if (!status.running || !status.webui_url) {
            toast(status.installed ? "请先启动 SnowLuma" : "请先安装并启动 SnowLuma", "warn", 3000);
            return;
        }
        const url = currentWebUIUrl();
        $("webui-url-field").value = url;
        $("webui-open-link").href = url;
        const bindHost = String(status.webui_bind_host || "").trim();
        const localOnly = LOOPBACK_BIND_HOSTS.includes(bindHost);
        $("webui-ip-hint").textContent = localOnly
            ? "当前 WebUI 仅监听本机（127.0.0.1），其他设备无法访问；可在配置里把监听地址改为 0.0.0.0。"
            : "地址已按当前访问的 IP 自动适配；远程访问 AstrBot 时不会再指向 127.0.0.1。";

        const passwordField = $("webui-password-field");
        passwordField.value = S.revealedPassword || "";
        passwordField.type = "password";
        passwordField.placeholder = status.password_managed ? "已保存，点击显示" : "首次启动自动生成";
        $("btn-toggle-webui-password").textContent = "显示";
        $("webui-modal").classList.add("visible");
    }

    async function toggleWebUIPassword() {
        const field = $("webui-password-field");
        const button = $("btn-toggle-webui-password");
        if (field.type === "text") {
            field.type = "password";
            button.textContent = "显示";
            return;
        }
        try {
            const password = await getPasswordPlain();
            if (!password) {
                toast("当前还没有受管密码", "warn");
                return;
            }
            field.value = password;
            field.type = "text";
            button.textContent = "隐藏";
        } catch (error) {
            toast("读取密码失败：" + error.message, "err", 4000);
        }
    }

    async function copyText(text, okMessage) {
        if (!text) { toast("没有可复制的内容", "warn", 2500); return false; }
        try {
            await navigator.clipboard.writeText(text);
            toast(okMessage || "已复制", "ok", 1600);
            return true;
        } catch (error) {
            const area = document.createElement("textarea");
            area.value = text;
            area.style.position = "fixed";
            area.style.opacity = "0";
            document.body.appendChild(area);
            area.select();
            try {
                document.execCommand("copy");
                toast(okMessage || "已复制", "ok", 1600);
                return true;
            } catch (inner) {
                toast("复制失败，请手动选择文本", "err", 3000);
                return false;
            } finally {
                area.remove();
            }
        }
    }

    async function getPasswordPlain() {
        if (S.revealedPassword) return S.revealedPassword;
        const data = await apiGet("password/reveal");
        const password = (data && data.password) || "";
        if (password) {
            S.revealedPassword = password;
            renderPassword(S.status);
        }
        return password;
    }

    async function actionRevealPassword() {
        if (S.revealedPassword) {
            S.revealedPassword = "";
            renderPassword(S.status);
            return;
        }
        try {
            const password = await getPasswordPlain();
            if (!password) toast("当前还没有受管密码", "warn");
        } catch (error) {
            toast("读取密码失败：" + error.message, "err", 4000);
        }
    }

    async function actionCopyPassword() {
        try {
            const password = await getPasswordPlain();
            await copyText(password, "WebUI 密码已复制");
        } catch (error) {
            toast("读取密码失败：" + error.message, "err", 4000);
        }
    }

    async function actionResetPassword() {
        if (!(await confirmDialog("将生成新的随机 WebUI 密码并立即生效（当前会话会失效）。继续？", "重置密码"))) return;
        const result = await run("reset-password", () => apiPost("password/reset"));
        if (!result) return;
        if (result.password) {
            S.revealedPassword = result.password;
            renderPassword(S.status);
            await copyText(result.password, "新密码已复制");
        }
        toast(result.message || (result.ok ? "密码已重置" : "重置失败"), result.ok ? "ok" : "err", result.ok ? 4000 : 6000);
        refreshStatus();
    }

    async function actionCopyWebUIUrl() {
        const url = currentWebUIUrl();
        if (!url) { toast("WebUI 地址不可用", "warn", 2500); return; }
        await copyText(url, "WebUI 地址已复制");
    }

    // ------------------------------------------------------------------
    // Install
    // ------------------------------------------------------------------

    async function loadReleases(force) {
        try {
            const data = await apiGet("releases", force ? { force: 1 } : undefined);
            S.releases = (data && data.releases) || [];
            const select = $("dl-version");
            const previous = select.value;
            const options = ['<option value="latest">latest（最新版）</option>'];
            S.releases.forEach((release) => {
                const flags = [];
                if (release.prerelease) flags.push("预发布");
                if (release.has_full === false && release.has_lite === false) flags.push("无本平台包");
                options.push('<option value="' + esc(release.tag) + '">' + esc(release.tag) +
                    (flags.length ? " [" + flags.join("/") + "]" : "") + "</option>");
            });
            select.innerHTML = options.join("");
            if (previous && Array.from(select.options).some((option) => option.value === previous)) {
                select.value = previous;
            }
        } catch (error) {
            toast("获取版本列表失败：" + error.message, "err", 5000);
        }
    }

    async function openDownload() {
        try {
            const config = await apiGet("config");
            S.mirrors = Array.isArray(config.download_mirrors) ? config.download_mirrors.slice() : [];
            $("dl-mirror-input").value = config.download_mirror || "";
            renderMirrorMenu();
            setMirrorMenu(false);

            const status = S.status || {};
            $("dl-current").textContent = status.installed
                ? "当前已安装 " + (status.installed_version || "未知版本") +
                    (status.release_flavor ? "（" + status.release_flavor + "）" : "") +
                    "；可切换版本或重新安装，用户数据会保留。"
                : "尚未安装 SnowLuma，选择版本后点「安装 / 更新」。";

            $("download-modal").classList.add("visible");
            if (!S.releases.length) await loadReleases(false);
            const select = $("dl-version");
            const configured = config.snowluma_version || "latest";
            if (Array.from(select.options).some((option) => option.value === configured)) {
                select.value = configured;
            }
            $("dl-flavor").value = config.release_flavor || status.release_flavor || "full";
            $("btn-dl-uninstall").style.display = status.installed ? "" : "none";
        } catch (error) {
            toast("读取下载设置失败：" + error.message, "err", 5000);
        }
    }

    function closeDownload() {
        setMirrorMenu(false);
        $("download-modal").classList.remove("visible");
    }

    // Serialize saves instead of dropping them: blur fires before a menu click,
    // and both must reach the backend so the last choice wins.
    let downloadOptionsChain = Promise.resolve();
    function saveDownloadOptions(patch, notify) {
        downloadOptionsChain = downloadOptionsChain.then(async () => {
            try {
                const result = await apiPost("download/options", patch);
                if (result && result.ok) {
                    if (notify) toast(notify, "ok", 1600);
                } else if (result) {
                    toast(result.message || "保存下载设置失败", "err", 4000);
                }
                return result;
            } catch (error) {
                toast("保存下载设置失败：" + (error.message || error), "err", 4000);
                return null;
            }
        });
        return downloadOptionsChain;
    }

    let mirrorSaveTimer = null;
    function queueMirrorSave() {
        clearTimeout(mirrorSaveTimer);
        mirrorSaveTimer = setTimeout(() => {
            saveDownloadOptions({ download_mirror: $("dl-mirror-input").value.trim() });
        }, 700);
    }

    async function actionInstall() {
        const version = $("dl-version").value || "latest";
        const flavor = $("dl-flavor").value || "full";
        const message = S.status && S.status.installed
            ? "将安装 " + version + "（" + flavor + "）包，程序文件会被替换，用户数据保留。继续？"
            : "将下载并安装 SnowLuma " + version + "（" + flavor + "）包。继续？";
        if (!(await confirmDialog(message, "开始安装"))) return;
        await saveDownloadOptions({ snowluma_version: version, release_flavor: flavor });

        let sudoEnc = "";
        try {
            const deps = await apiGet("deps/status");
            if (deps && deps.linux && Array.isArray(deps.missing) && deps.missing.length) {
                sudoEnc = await promptSudo(
                    "安装前需要先安装 Linux 依赖：" + deps.missing.join("、") + "（仅本次使用）"
                );
                if (!sudoEnc) return;
            }
        } catch (error) { /* backend checks again */ }

        closeDownload();
        let result = await run("install", () =>
            apiPost("install", { version: version, flavor: flavor, sudo_password_enc: sudoEnc })
        );
        if (result && result.need_sudo) {
            const enc = await promptSudo("缺少 Linux 依赖，需要 sudo 密码（仅本次使用）");
            if (enc) {
                result = await run("install", () =>
                    apiPost("install", { version: version, flavor: flavor, sudo_password_enc: enc })
                );
            }
        }
        if (result) toast(result.message || (result.ok ? "安装完成" : "安装失败"), result.ok ? "ok" : "err", 5000);
        refreshStatus();
    }

    async function actionUninstall() {
        if (!(await confirmDialog("将删除本插件管理的 SnowLuma 安装目录（含 config/ 与账号数据），不可撤销。继续？", "确认卸载"))) return;
        const result = await run("uninstall", () => apiPost("uninstall", { purge: true }));
        if (result) toast(result.message || (result.ok ? "已卸载" : "卸载失败"), result.ok ? "ok" : "err", 5000);
        refreshStatus();
    }

    // ------------------------------------------------------------------
    // Config
    // ------------------------------------------------------------------

    const CONFIG_FIELDS = [
        ["deploy_mode", "value"],
        ["snowluma_port", "number"],
        ["webui_bind_host", "value"],
        ["external_host", "value"],
        ["external_port", "number"],
        ["qq_number", "value"],
        ["qq_path", "value"],
        ["qq_display", "value"],
        ["vnc_port", "number"],
        ["astrbot_config_path", "value"],
        ["ws_host_override", "value"],
        ["sync_connection_name", "value"],
        ["auto_start", "check"],
        ["auto_start_after_install", "check"],
        ["auto_sync", "check"],
        ["auto_hook", "check"],
        ["auto_start_qq", "check"],
        ["auto_accept_agreements", "check"],
    ];

    function renderMirrorMenu() {
        const menu = $("dl-mirror-menu");
        const input = $("dl-mirror-input");
        if (!menu || !input) return;
        const current = input.value.trim();
        const options = [{ value: "", label: "官方 GitHub（不使用镜像）", tag: "官方" }];
        S.mirrors.forEach((mirror, index) => {
            options.push({ value: mirror, label: mirror, tag: index === 0 ? "默认" : "" });
        });
        menu.innerHTML = options.map((option) => {
            const selected = option.value === current;
            const meta = [option.tag ? '<span class="mirror-tag">' + esc(option.tag) + "</span>" : ""]
                .concat(selected ? ['<span class="mirror-check">✓</span>'] : [])
                .join("");
            return '<button class="mirror-option' + (selected ? " selected" : "") + '" type="button" role="option"' +
                ' aria-selected="' + (selected ? "true" : "false") + '"' +
                ' data-mirror="' + esc(option.value) + '">' +
                '<span class="mirror-url">' + esc(option.label) + "</span>" +
                (meta ? '<span class="mirror-meta">' + meta + "</span>" : "") +
                "</button>";
        }).join("");
    }

    function setMirrorMenu(open) {
        const picker = $("dl-mirror-picker");
        const menu = $("dl-mirror-menu");
        const toggle = $("dl-mirror-toggle");
        if (!picker || !menu || !toggle) return;
        picker.classList.toggle("open", open);
        menu.classList.toggle("visible", open);
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
        if (!open) return;
        const selected = menu.querySelector(".mirror-option.selected");
        if (selected) selected.scrollIntoView({ block: "nearest" });
    }

    async function openConfig() {
        try {
            const config = await apiGet("config");
            CONFIG_FIELDS.forEach(([key, kind]) => {
                const input = $("cfg-" + key);
                if (!input) return;
                const value = config[key];
                if (kind === "check") input.checked = !!value;
                else input.value = value == null ? "" : value;
            });
            $("cfg-webui_password").value = "";
            $("cfg-webui_password").type = "password";
            $("cfg-vnc_password").value = "";
            applyTheme(config.ui_theme || S.themeMode || "auto");
            $("config-modal").classList.add("visible");
        } catch (error) {
            toast("读取配置失败：" + error.message, "err", 5000);
        }
    }

    function closeConfig() {
        setMirrorMenu(false);
        $("config-modal").classList.remove("visible");
    }

    async function saveConfig() {
        const payload = {};
        CONFIG_FIELDS.forEach(([key, kind]) => {
            const input = $("cfg-" + key);
            if (!input) return;
            if (kind === "check") payload[key] = input.checked;
            else if (kind === "number") payload[key] = Number(input.value) || 0;
            else payload[key] = input.value;
        });
        const password = $("cfg-webui_password").value.trim();
        if (password) payload.webui_password = password;
        const vncPassword = $("cfg-vnc_password").value.trim();
        if (vncPassword) payload.vnc_password = vncPassword;

        const result = await run("config-save", () => apiPost("config/save", payload));
        if (!result) return;
        if (result.ok) {
            toast("配置已保存", "ok");
            closeConfig();
            if (result.status) {
                S.status = result.status;
                render(result.status);
            }
            refreshStatus();
        } else {
            toast(result.message || "保存失败", "err", 5000);
        }
    }

    async function revealPassword() {
        try {
            const password = await getPasswordPlain();
            const input = $("cfg-webui_password");
            if (password) {
                input.value = password;
                input.type = "text";
                renderPassword(S.status);
                toast("已显示当前受管密码", "ok", 2000);
            } else {
                toast("当前没有受管密码", "warn");
            }
        } catch (error) {
            toast("读取密码失败：" + error.message, "err");
        }
    }

    // ------------------------------------------------------------------
    // Wiring
    // ------------------------------------------------------------------

    function bindEvents() {
        $("btn-toggle-power").addEventListener("click", actionPower);
        $("btn-sync").addEventListener("click", actionSync);
        $("btn-qq-launch").addEventListener("click", actionStartQQ);
        $("btn-hook-all").addEventListener("click", actionHookAll);
        $("btn-restart").addEventListener("click", actionRestart);
        $("btn-cleanup").addEventListener("click", actionCleanup);
        $("btn-refresh").addEventListener("click", () => { refreshStatus(); toast("已刷新", "ok", 1200); });
        $("btn-check-update").addEventListener("click", actionCheckUpdate);
        $("btn-qq-cleanup").addEventListener("click", actionCleanupQQ);
        $("btn-qq-login").addEventListener("click", openQQLoginModal);
        $("btn-fix-linux").addEventListener("click", actionFixLinux);
        $("btn-qq-repair-ui").addEventListener("click", actionRepairQQ);
        $("btn-install-deps").addEventListener("click", actionInstallDeps);
        $("btn-qq-login-refresh").addEventListener("click", refreshQQLogin);
        $("btn-qq-login-restart").addEventListener("click", restartQQLogin);
        $("btn-copy-qq-vnc").addEventListener("click", actionCopyQQVnc);
        $("btn-close-qq-login").addEventListener("click", closeQQLoginModal);
        $("btn-qq-live").addEventListener("click", toggleQQLive);
        bindQQLiveEvents();
        $("btn-replay-guide").addEventListener("click", () => {
            closeConfig();
            startOnboarding();
        });
        $("btn-open-config").addEventListener("click", () => openConfig());
        $("btn-open-download").addEventListener("click", () => {
            closeConfig();
            openDownload();
        });
        $("btn-dl-close").addEventListener("click", closeDownload);
        $("btn-dl-install").addEventListener("click", actionInstall);
        $("btn-dl-uninstall").addEventListener("click", actionUninstall);
        $("dl-version").addEventListener("change", () => {
            saveDownloadOptions({ snowluma_version: $("dl-version").value || "latest" });
        });
        $("dl-flavor").addEventListener("change", () => {
            saveDownloadOptions({ release_flavor: $("dl-flavor").value || "full" });
        });
        $("dl-mirror-toggle").addEventListener("click", () => {
            setMirrorMenu(!$("dl-mirror-menu").classList.contains("visible"));
        });
        $("dl-mirror-input").addEventListener("focus", () => setMirrorMenu(true));
        $("dl-mirror-input").addEventListener("input", () => {
            renderMirrorMenu();
            queueMirrorSave();
        });
        $("dl-mirror-input").addEventListener("blur", () => {
            clearTimeout(mirrorSaveTimer);
            saveDownloadOptions({ download_mirror: $("dl-mirror-input").value.trim() });
        });
        $("dl-mirror-input").addEventListener("keydown", (event) => {
            if (event.key === "Escape") {
                setMirrorMenu(false);
                $("dl-mirror-input").blur();
            } else if (event.key === "ArrowDown") {
                event.preventDefault();
                setMirrorMenu(true);
            } else if (event.key === "Enter") {
                setMirrorMenu(false);
                clearTimeout(mirrorSaveTimer);
                saveDownloadOptions(
                    { download_mirror: $("dl-mirror-input").value.trim() },
                    "下载镜像已生效"
                );
            }
        });
        $("dl-mirror-menu").addEventListener("click", (event) => {
            const option = event.target.closest(".mirror-option");
            if (!option) return;
            $("dl-mirror-input").value = option.dataset.mirror || "";
            renderMirrorMenu();
            setMirrorMenu(false);
            clearTimeout(mirrorSaveTimer);
            saveDownloadOptions(
                { download_mirror: $("dl-mirror-input").value.trim() },
                "下载镜像已生效"
            );
        });
        document.addEventListener("click", (event) => {
            if (!event.target.closest("#dl-mirror-picker")) setMirrorMenu(false);
        });
        $("btn-config-cancel").addEventListener("click", closeConfig);
        $("btn-config-save").addEventListener("click", saveConfig);
        $("cfg-light-mode").addEventListener("change", (event) => {
            const theme = event.target.checked ? "light" : "dark";
            S.themeTouched = true;
            applyTheme(theme, true);
            run("ui-theme", () => apiPost("ui/theme", { theme: theme }));
        });
        $("link-follow-theme").addEventListener("click", (event) => {
            event.preventDefault();
            S.themeTouched = false;
            applyTheme("auto", true);
            run("ui-theme", () => apiPost("ui/theme", { theme: "auto" }));
        });
        $("btn-reveal-password").addEventListener("click", revealPassword);
        $("btn-copy-password-modal").addEventListener("click", actionCopyPassword);
        $("btn-open-webui").addEventListener("click", openWebUIModal);
        $("btn-copy-webui-url").addEventListener("click", actionCopyWebUIUrl);
        $("btn-copy-webui-password").addEventListener("click", actionCopyPassword);
        $("btn-toggle-webui-password").addEventListener("click", toggleWebUIPassword);
        $("btn-close-webui").addEventListener("click", () => $("webui-modal").classList.remove("visible"));
        $("webui-open-link").addEventListener("click", (event) => {
            const status = S.status || {};
            if (!(status.running && status.webui_url)) {
                event.preventDefault();
                toast(status.installed ? "请先启动 SnowLuma" : "请先安装并启动 SnowLuma", "warn", 3000);
            }
        });
        $("btn-clear-log").addEventListener("click", () => {
            S.logs = [];
            S.logOffset = S.status ? (S.status.log_count || 0) : 0;
            renderLogs();
        });
        $("log-pause").addEventListener("change", (event) => {
            S.paused = event.target.checked;
            if (!S.paused) refreshLogs();
        });
        $("log-source").addEventListener("change", (event) => {
            S.logSource = event.target.value;
            S.logs = [];
            renderLogs();
            refreshLogs();
        });

        $("ob-card").addEventListener("click", (event) => {
            const button = event.target.closest("button[data-ob]");
            if (!button) return;
            const act = button.dataset.ob;
            if (act === "next") {
                S.onboarding.idx = Math.min(S.onboarding.idx + 1, S.onboarding.steps.length - 1);
                renderOnboarding();
            } else if (act === "prev") {
                S.onboarding.idx = Math.max(0, S.onboarding.idx - 1);
                renderOnboarding();
            } else {
                finishOnboarding();
            }
        });
        window.addEventListener("resize", () => {
            if ($("onboarding").classList.contains("visible")) {
                const step = S.onboarding.steps[S.onboarding.idx];
                if (step && step.type === "spotlight") positionOnboarding();
            }
        });
        window.addEventListener("scroll", () => {
            if ($("onboarding").classList.contains("with-spotlight")) positionOnboarding();
        }, { passive: true });

        document.addEventListener("click", (event) => {
            const target = event.target.closest("[data-action]");
            if (!target) return;
            const action = target.dataset.action;
            if (action === "sync") { actionSync(); return; }
            if (action === "start-qq-sudo") { actionStartQQ(); return; }
            if (action === "hook-load") { actionHook(Number(target.dataset.pid || 0), "load"); return; }
            if (action === "hook-unload") { actionHook(Number(target.dataset.pid || 0), "unload"); return; }
            if (action === "open-webui") { openWebUIModal(); return; }
            if (action === "reveal-password") { actionRevealPassword(); return; }
            if (action === "copy-password") { actionCopyPassword(); return; }
            if (action === "reset-password") { actionResetPassword(); return; }
            if (action === "accept-agreements") { actionAcceptAgreements(); }
        });

        document.querySelectorAll(".modal").forEach((modal) => {
            modal.addEventListener("click", (event) => {
                if (event.target === modal) modal.classList.remove("visible");
            });
        });
        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape") {
                document.querySelectorAll(".modal.visible").forEach((modal) => modal.classList.remove("visible"));
            }
        });
    }

    function applyContext(context) {
        S.context = context || {};
        if (S.context.pageTitle) document.title = S.context.pageTitle + " · SnowLuma Go";
        if (!S.themeTouched && S.themeMode === "auto") applyTheme("auto");
    }

    async function init() {
        S.bridge = await resolveBridge();
        try {
            const context = await Promise.race([S.bridge.ready(), sleep(4000).then(() => ({}))]);
            applyContext(context);
        } catch (error) {
            applyContext({});
        }
        if (S.bridge.onContext) {
            S.bridge.onContext((next) => applyContext(next));
        }
        bindEvents();
        await refreshStatus();
        await refreshLogs();
        loadReleases(false);
        void maybeShowOnboarding();
        setInterval(refreshLogs, LOG_INTERVAL);
        document.addEventListener("visibilitychange", () => {
            if (!document.hidden) { refreshStatus(); refreshLogs(); }
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
